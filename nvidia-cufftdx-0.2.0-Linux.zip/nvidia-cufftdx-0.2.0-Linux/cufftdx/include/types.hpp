// Copyright (c) 2019, NVIDIA CORPORATION.  All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.  Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#ifndef CUFFTDX_TYPES_HPP__
#define CUFFTDX_TYPES_HPP__

#include <cuda.h>

// We require target architecture to be Volta (sm_60) or higher
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ < 600
static_assert(false, "GPU architecture sm_60 or higher required. Please recompile with -arch sm_60");
#else
namespace cufftdx {
    namespace detail {
        template<class T>
        struct complex_base {
            using value_type = T;

            complex_base()                    = default;
            complex_base(const complex_base&) = default;

            __device__ __forceinline__ __host__ constexpr complex_base(value_type re, value_type im): x(re), y(im) {}

            __device__ __forceinline__ __host__ constexpr value_type real() const { return x; }
            __device__ __forceinline__ __host__ constexpr value_type imag() const { return y; }
            __device__ __forceinline__ __host__ void real(value_type re) { x = re; }
            __device__ __forceinline__ __host__ void imag(value_type im) { y = im; }

            __device__ __forceinline__ __host__ complex_base& operator=(value_type re) {
                x = re;
                y = value_type();
                return *this;
            }
            __device__ __forceinline__ __host__ complex_base& operator+=(value_type re) {
                x += re;
                return *this;
            }
            __device__ __forceinline__ __host__ complex_base& operator-=(value_type re) {
                x -= re;
                return *this;
            }
            __device__ __forceinline__ __host__ complex_base& operator*=(value_type re) {
                x *= re;
                y *= re;
                return *this;
            }
            __device__ __forceinline__ __host__ complex_base& operator/=(value_type re) {
                x /= re;
                y /= re;
                return *this;
            }

            template<class K>
            __device__ __forceinline__ __host__ complex_base& operator=(const complex_base<K>& other) {
                x = other.real();
                y = other.imag();
                return *this;
            }

            /// \internal
            value_type x, y;
        };

        template<class T>
        struct complex;

        template<>
        struct alignas(2 * sizeof(float)) complex<float>: complex_base<float> {
        private:
            using base_type = complex_base<float>;

        public:
            using value_type        = float;
            complex()               = default;
            complex(const complex&) = default;
            __device__ __forceinline__ __host__ constexpr complex(float re, float im): base_type(re, im) {}
            __device__ __forceinline__ __host__ explicit constexpr complex(const complex<double>& other);
            using base_type::operator+=;
            using base_type::operator-=;
            using base_type::operator*=;
            using base_type::operator/=;
            using base_type::operator=;
        };

        template<>
        struct alignas(2 * sizeof(double)) complex<double>: complex_base<double> {
        private:
            using base_type = complex_base<double>;

        public:
            using value_type        = double;
            complex()               = default;
            complex(const complex&) = default;
            __device__ __forceinline__ __host__ constexpr complex(double re, double im): base_type(re, im) {}
            __device__ __forceinline__ __host__ explicit constexpr complex(const complex<float>& other);
            using base_type::operator+=;
            using base_type::operator-=;
            using base_type::operator*=;
            using base_type::operator/=;
            using base_type::operator=;
        };

        // For FFT computations, complex<half2> should be in RRII layout.
        template<>
        struct alignas(2 * sizeof(__half2)) complex<__half2> {
            using value_type        = __half2;
            complex()               = default;
            complex(const complex&) = default;
            __device__ __forceinline__ __host__ complex(value_type re, value_type im): x(re), y(im) {}

            __device__ __forceinline__ __host__ value_type real() const { return x; }
            __device__ __forceinline__ __host__ value_type imag() const { return y; }
            __device__ __forceinline__ __host__ void real(value_type re) { x = re; }
            __device__ __forceinline__ __host__ void imag(value_type im) { y = im; }

            __device__ __forceinline__ __host__ complex& operator=(value_type re) {
                x = re;
                y = value_type();
                return *this;
            }
            __device__ __forceinline__ complex& operator+=(value_type re) {
                x += re;
                return *this;
            }
            __device__ __forceinline__ complex& operator-=(value_type re) {
                x -= re;
                return *this;
            }
            __device__ __forceinline__ complex& operator*=(value_type re) {
                x *= re;
                y *= re;
                return *this;
            }
            __device__ __forceinline__ complex& operator/=(value_type re) {
                x /= re;
                y /= re;
                return *this;
            }

            __device__ __forceinline__ __host__ complex& operator=(const complex& other) {
                x = other.real();
                y = other.imag();
                return *this;
            }

            /// \internal
            value_type x, y;
        };

        __forceinline__ constexpr complex<float>::complex(const complex<double>& other):
            complex_base<float>(other.real(), other.imag()) {};

        __forceinline__ constexpr complex<double>::complex(const complex<float>& other):
            complex_base<double>(other.real(), other.imag()) {};
    } // namespace detail

    template<class T>
    using complex = typename detail::complex<T>;
} // namespace cufftdx
#endif // __CUDA_ARCH__ >= 600

#endif // CUFFTDX_TYPES_HPP__
