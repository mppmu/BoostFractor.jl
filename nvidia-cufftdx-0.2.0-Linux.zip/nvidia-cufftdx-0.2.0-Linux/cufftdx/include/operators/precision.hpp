// Copyright (c) 2019, NVIDIA CORPORATION.  All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.  Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#ifndef CUFFTDX_OPERATORS_PRECISION_HPP
#define CUFFTDX_OPERATORS_PRECISION_HPP

#include <type_traits>
#include <cuda_fp16.h>

#include "../detail/expressions.hpp"

namespace cufftdx {
    namespace detail {
        template<class T>
        struct is_supported_fp_type:
            std::integral_constant<bool,
                                   std::is_same<float, typename std::remove_cv<T>::type>::value ||
                                       std::is_same<double, typename std::remove_cv<T>::type>::value ||
                                       std::is_same<__half, typename std::remove_cv<T>::type>::value> {};
    } // namespace detail

    template<class T = float>
    struct Precision: detail::operator_expression {
        using type = typename std::remove_cv<T>::type;
        static_assert(detail::is_supported_fp_type<type>::value, "Precision must be double, float, or __half.");
    };
} // namespace cufftdx

#endif // CUFFTDX_OPERATORS_TYPE_HPP
