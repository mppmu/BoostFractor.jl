// Copyright (c) 2019, NVIDIA CORPORATION.  All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.  Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#ifndef CUFFTDX_DETAIL_FFT_EXECUTION_HPP
#define CUFFTDX_DETAIL_FFT_EXECUTION_HPP

#include <type_traits>
#include <cuda.h>
#include <cassert>

#include "fft_description.hpp"

namespace cufftdx {
    namespace detail {
        template<class T>
        inline __device__ constexpr T get_zero() {
            return 0.;
        }

        template<>
        inline __device__ constexpr __half2 get_zero<__half2>() {
            // This return __half2 with zeros everywhere
            return __half2 {};
        }

        // C2C OR (C2R AND ept == 2)
        template<class FFT, class ComplexType>
        inline __device__ auto preprocess(ComplexType * /* input */) //
            -> typename std::enable_if<(type_of<FFT>::value == fft_type::c2c) ||
                                       ((type_of<FFT>::value == fft_type::c2r) && //
                                        (FFT::elements_per_thread == 2))>::type {
            // NOP, C2C and C2R with ept == 2 don't require any preprocess
        }

        // R2C AND ept > 2
        template<class FFT, class ComplexType>
        inline __device__ auto preprocess(ComplexType* input) //
            -> typename std::enable_if<(type_of<FFT>::value == fft_type::r2c)>::type {
            using scalar_type         = typename ComplexType::value_type;
            static constexpr auto ept = FFT::elements_per_thread;

            // Input has packed real values (this means .y has real values), this
            // unpacks input so every complex value is {real, 0}
            for (unsigned int i = ept; i > 1; i--) {
                (reinterpret_cast<scalar_type*>(input))[2 * i - 1] = get_zero<scalar_type>();
                (reinterpret_cast<scalar_type*>(input))[2 * i - 2] = (reinterpret_cast<scalar_type*>(input))[i - 1];
            }
            // input[0].x is in the right position from the start, just need to set .y to zero
            input[0].y = get_zero<scalar_type>();
        }

        // C2R AND ept > 2
        template<class FFT, class ComplexType>
        inline __device__ auto preprocess(ComplexType* input) //
            -> typename std::enable_if<(type_of<FFT>::value == fft_type::c2r) && (FFT::elements_per_thread > 2)>::type {
            using scalar_type         = typename ComplexType::value_type;
            static constexpr auto ept = FFT::elements_per_thread;

            // If ept is even we need to fill one value less
            static constexpr unsigned number_of_values_to_fill = (ept % 2 == 0) ? (ept / 2 - 1) : (ept / 2);
            for (unsigned int i = 0; i < number_of_values_to_fill; i++) {
                input[ept - i - 1] = input[i + 1];
                // conjugate
                input[ept - i - 1].y = -input[ept - i - 1].y;
            }
        }

        // C2C or R2C
        template<class FFT, class ComplexType>
        inline __device__ auto postprocess(ComplexType* input) //
            -> typename std::enable_if<(type_of<FFT>::value != fft_type::c2r)>::type {
            // NOP, C2R and R2C don't require postprocess
        }

        // C2R
        template<class FFT, class ComplexType>
        inline __device__ auto postprocess(ComplexType* input) //
            -> typename std::enable_if<(type_of<FFT>::value == fft_type::c2r)>::type {
            using scalar_type         = typename ComplexType::value_type;
            static constexpr auto ept = FFT::elements_per_thread;

            // Pack real values
            for (unsigned int i = 1; i < ept; i++) {
                (reinterpret_cast<scalar_type*>(input))[i] = (reinterpret_cast<scalar_type*>(input))[2 * i];
            }
        }

        template<class... Operators>
        class fft_execution: public fft_description<Operators...>, public execution_description_expression
        {
            using base_type      = fft_description<Operators...>;
            using execution_type = fft_execution<Operators...>;

        protected:
            // Precision type
            using typename base_type::this_fft_precision_t;

            /// ---- Constraints

            // We need Block or Thread to be specified exactly once
            static constexpr bool is_thread_execution = has_n_of<1, fft_operator::thread, execution_type>::value;
            static constexpr bool is_block_execution  = has_n_of<1, fft_operator::block, execution_type>::value;
            static_assert((is_thread_execution != is_block_execution), "Can't create FFT with two execution operators");

            /// ---- Configuration traits

            // Defaults to 2 when Size is not defined
            static constexpr unsigned int elements_per_thread =
                check_and_get_trait<fft_operator::elements_per_thread, execution_type>::value;
        };

        #ifdef __CUDA_ARCH__
            #if __CUDA_ARCH__ > 750
                #define CUFFTDX_DETAIL_EXECUTION_SM_VALUE 750
            #else
                #define CUFFTDX_DETAIL_EXECUTION_SM_VALUE __CUDA_ARCH__
            #endif
        #else
            #define CUFFTDX_DETAIL_EXECUTION_SM_VALUE base_type::this_fft_sm_v
        #endif

        template<class... Operators>
        class fft_thread_execution: public fft_execution<Operators...>
        {
            using this_type = fft_thread_execution<Operators...>;
            using base_type = fft_execution<Operators...>;
            using typename base_type::this_fft_precision_t;

        protected:
            // Thead can't have block-only operators
            static constexpr bool has_block_only_operators = has_any_block_operator<base_type>::value;
            static_assert(!has_block_only_operators, "FFT for thread execution can't contain block-only operators");

            // Thread, Size and Precision constrains
            static constexpr bool valid_size_for_thread_fp16 =
                !base_type::has_size || // Size<> was not defined
                !std::is_same<__half, this_fft_precision_t>::value ||
                ((base_type::this_fft_size_v <= 32) && (base_type::this_fft_size_v >= 2));
            static constexpr bool valid_size_for_thread_fp32 =
                !base_type::has_size || // Size<> was not defined
                !std::is_same<float, this_fft_precision_t>::value ||
                ((base_type::this_fft_size_v <= 32) && (base_type::this_fft_size_v >= 2));
            static constexpr bool valid_size_for_thread_fp64 =
                !base_type::has_size || // Size<> was not defined
                !std::is_same<double, this_fft_precision_t>::value ||
                ((base_type::this_fft_size_v <= 16) && (base_type::this_fft_size_v >= 2));
            static_assert(valid_size_for_thread_fp16,
                          "Thread execution in fp16 precision supports sizes in range [2; 32]");
            static_assert(valid_size_for_thread_fp32,
                          "Thread execution in fp32 precision supports sizes in range [2; 32]");
            static_assert(valid_size_for_thread_fp64,
                          "Thread execution in fp64 precision supports sizes in range [2; 16]");

        public:
            using value_type  = typename make_complex_type<this_fft_precision_t>::cufftdx_type;
            using input_type  = value_type;
            using output_type = value_type;

            inline __device__ void execute(value_type* input) {
                static_assert(base_type::is_complete, "Can't execute, FFT description is not complete");
                using database::detail::block_fft_record;
                using database::detail::search_by_ept;

                // [TODO] C2R/R2C are always using C2C, and right now database has only C2C records
                using block_fft_record_t = block_fft_record<base_type::this_fft_size_v,
                                                            this_fft_precision_t,
                                                            base_type::this_fft_type_v,
                                                            base_type::this_fft_direction_v,
                                                            CUFFTDX_DETAIL_EXECUTION_SM_VALUE>;
                static_assert(block_fft_record_t::defined, "This FFT configuration is not supported");
                using block_fft_implementation_t =
                    typename search_by_ept<base_type::this_fft_size_v, typename block_fft_record_t::blobs>::type;
                static constexpr auto function_id = block_fft_implementation_t::function_id;

                preprocess<this_type>(input);
                using scalar_type = typename value_type::value_type;
                database::detail::cufftdx_private_function<function_id, scalar_type, 1>(input, nullptr);
                postprocess<this_type>(input);
            }

            // T - can be any type if it's alignment and size are the same as those of ::value_type
            template<class T /* TODO = typename make_vector_type<make_scalar_type<value_type>, 2>::type */>
            inline __device__ auto execute(T* input) //
                -> typename std::enable_if<!std::is_void<T>::value && (sizeof(T) == sizeof(value_type)) &&
                                           (alignof(T) == alignof(value_type))>::type {
                return execute(reinterpret_cast<value_type*>(input));
            }

            // This
            template<class T>
            inline __device__ auto execute(T* input) //
                -> typename std::enable_if<std::is_void<T>::value || (sizeof(T) != sizeof(value_type)) ||
                                           (alignof(T) != alignof(value_type))>::type {
                static constexpr bool condition =
                    std::is_void<T>::value || (sizeof(T) != sizeof(value_type)) || (alignof(T) != alignof(value_type));
                static_assert(condition, "Incorrect value type is used, try using ::value_type");
            }

            static constexpr unsigned int elements_per_thread = base_type::elements_per_thread;
            static constexpr unsigned int storage_size        = elements_per_thread;

            static constexpr unsigned int implicit_type_batching = std::is_same<this_fft_precision_t, __half>::value ? 2 : 1;
        };

        template<class... Operators>
        constexpr unsigned int fft_thread_execution<Operators...>::elements_per_thread;
        template<class... Operators>
        constexpr unsigned int fft_thread_execution<Operators...>::storage_size;
        template<class... Operators>
        constexpr unsigned int fft_thread_execution<Operators...>::implicit_type_batching;

        // C2C
        template<class FFT, class ComplexType>
        inline __device__ auto block_preprocess(ComplexType* /* input */, ComplexType * /* smem */) //
            -> typename std::enable_if<(type_of<FFT>::value == fft_type::c2c)>::type {
            // NOP, C2C and C2R with ept == 2 don't require any preprocess
        }

        // R2C AND ept > 2
        template<class FFT, class ComplexType>
        inline __device__ auto block_preprocess(ComplexType* input, ComplexType * /* smem */) //
            -> typename std::enable_if<(type_of<FFT>::value == fft_type::r2c)>::type {
            // Same implementation as thread_preprocess
            preprocess<FFT>(input);
        }

        // C2R, EPT == SIZE
        template<class FFT, class ComplexType>
        inline __device__ auto block_preprocess(ComplexType* input, ComplexType * /* smem */) //
            -> typename std::enable_if<(type_of<FFT>::value == fft_type::c2r) &&
                                       (FFT::elements_per_thread == size_of<FFT>::value)>::type {
            // Same implementation as thread_preprocess
            preprocess<FFT>(input);
        }

        // C2R, EPT < SIZE
        template<class FFT, class ComplexType>
        inline __device__ auto block_preprocess(ComplexType* input, ComplexType* smem) //
            -> typename std::enable_if<(type_of<FFT>::value == fft_type::c2r) &&
                                       (FFT::elements_per_thread < size_of<FFT>::value)>::type {
            using scalar_type                              = typename ComplexType::value_type;
            static constexpr auto ept                      = FFT::elements_per_thread;
            static constexpr auto fft_size                 = size_of<FFT>::value;
            static constexpr bool fft_size_is_even         = (fft_size % 2) == 0;

            // Move to the part of shared memory for that FFT batch
            ComplexType* smem_fft_batch = smem + (threadIdx.y * (fft_size / 2));
            for (unsigned int i = 0; i < (ept / 2); i++) {
                if(!(threadIdx.x == 0 && i == 0)) {
                    smem_fft_batch[threadIdx.x + (i * (fft_size / ept)) - 1] = input[i];
                }
            }
            if (!fft_size_is_even) {
                constexpr unsigned int i     = ept / 2;
                unsigned int           index = threadIdx.x + (i * (fft_size / ept)) - 1;
                if (index < (fft_size / 2)) {
                    smem_fft_batch[index] = input[i];
                }
            }
            __syncthreads();

            const unsigned int reversed_thread_id = (fft_size / ept) - threadIdx.x;
            for (unsigned int i = 0; i < (ept / 2); i++) {
                if(i < ((ept/2) - ((threadIdx.x == 0) && fft_size_is_even))) {
                    input[ept - 1 - i] = smem_fft_batch[reversed_thread_id + (i * (fft_size / ept)) - 1];
                    // conjugate
                    input[ept - 1 - i].y = -input[ept - 1 - i].y;
                }
            }
            if (!fft_size_is_even) {
                constexpr unsigned int i     = ept / 2;
                unsigned int           index = reversed_thread_id + (i * (fft_size / ept)) - 1;
                if (index < (fft_size / 2)) {
                    input[i] = smem_fft_batch[index];
                    // conjugate
                    input[i].y = -input[i].y;
                }
            }
        }

        template<class... Operators>
        class fft_block_execution: public fft_execution<Operators...>
        {
            using this_type = fft_block_execution<Operators...>;
            using base_type = fft_execution<Operators...>;
            using typename base_type::this_fft_precision_t;

        protected:
            // Block, Size and Precision constrains
            static constexpr bool valid_size_for_block_fp16 =
                !base_type::has_size || // Size<> was not defined
                !std::is_same<__half, this_fft_precision_t>::value ||
                ((base_type::this_fft_size_v <= 4096) && (base_type::this_fft_size_v >= 2));
            static constexpr bool valid_size_for_block_fp32 =
                !base_type::has_size || // Size<> was not defined
                !std::is_same<float, this_fft_precision_t>::value ||
                ((base_type::this_fft_size_v <= 4096) && (base_type::this_fft_size_v >= 2));
            static constexpr bool valid_size_for_block_fp64 =
                !base_type::has_size || // Size<> was not defined
                !std::is_same<double, this_fft_precision_t>::value ||
                ((base_type::this_fft_size_v <= 2048) && (base_type::this_fft_size_v >= 2));
            static_assert(valid_size_for_block_fp16,
                          "Block execution in fp16 precision supports sizes in range [2; 4096]");
            static_assert(valid_size_for_block_fp32,
                          "Block execution in fp32 precision supports sizes in range [2; 4096]");
            static_assert(valid_size_for_block_fp64,
                          "Block execution in fp64 precision supports sizes in range [2; 2048]");

        public:
            using value_type  = typename make_complex_type<this_fft_precision_t>::cufftdx_type;
            using input_type  = value_type;
            using output_type = value_type;

            inline __device__ void execute(value_type* input, void* shared_memory) {
                #if !defined(NDEBUG) && !defined(CUFFTDX_DISABLE_RUNTIME_ASSERTS)
                const bool block_dimension_x_is_correct = (blockDim.x == block_dim.x);
                assert(block_dimension_x_is_correct);
                const bool block_dimension_y_is_correct = (blockDim.y == block_dim.y);
                assert(block_dimension_y_is_correct);
                #endif

                static_assert(base_type::is_complete, "Can't execute, FFT description is not complete");
                using database::detail::block_fft_record;
                using database::detail::search_by_ept;

                // [TODO] C2R/R2C are always using C2C, and right now database has only C2C records
                using block_fft_record_t = block_fft_record<base_type::this_fft_size_v,
                                                            this_fft_precision_t,
                                                            base_type::this_fft_type_v,
                                                            base_type::this_fft_direction_v,
                                                            CUFFTDX_DETAIL_EXECUTION_SM_VALUE>;
                static_assert(block_fft_record_t::defined, "This FFT configuration is not supported");
                using block_fft_implementation_t =
                    typename search_by_ept<elements_per_thread, typename block_fft_record_t::blobs>::type;
                static constexpr auto function_id = block_fft_implementation_t::function_id;

                block_preprocess<this_type>(input, reinterpret_cast<value_type*>(shared_memory));
                using scalar_type = typename value_type::value_type;
                database::detail::cufftdx_private_function<function_id, scalar_type, 1 /* dynamic */>(
                    input, shared_memory);
                postprocess<this_type>(input);
            }

            // T - can be any type if its alignment and size are the same as those of ::value_type
            template<class T /* TODO = typename make_vector_type<make_scalar_type<value_type>, 2>::type */>
            inline __device__ auto execute(T* input, void* shared_memory) //
                -> typename std::enable_if<!std::is_void<T>::value && (sizeof(T) == sizeof(value_type)) &&
                                           (alignof(T) == alignof(value_type))>::type {
                return execute(reinterpret_cast<value_type*>(input), shared_memory);
            }

            template<class T>
            inline __device__ auto execute(T* /* input */, void * /* shared_memory */) //
                -> typename std::enable_if<std::is_void<T>::value || (sizeof(T) != sizeof(value_type)) ||
                                           (alignof(T) != alignof(value_type))>::type {
                static constexpr bool condition =
                    std::is_void<T>::value || (sizeof(T) != sizeof(value_type)) || (alignof(T) != alignof(value_type));
                static_assert(condition, "Incorrect value type is used, try using ::value_type");
            }

        private:
            inline static constexpr unsigned int get_shared_memory_size() {
                static_assert(base_type::is_complete, "Can't calculate shared memory, FFT description is not complete");
                using database::detail::block_fft_record;
                using database::detail::search_by_ept;

                using block_fft_record_t = block_fft_record<base_type::this_fft_size_v,
                                                            this_fft_precision_t,
                                                            base_type::this_fft_type_v,
                                                            base_type::this_fft_direction_v,
                                                            CUFFTDX_DETAIL_EXECUTION_SM_VALUE>;
                static_assert(block_fft_record_t::defined, "This FFT configuration is not supported");
                using block_fft_implementation_t =
                    typename search_by_ept<elements_per_thread, typename block_fft_record_t::blobs>::type;
                static_assert(!std::is_void<block_fft_implementation_t>::value,
                              "This FFT configuration is not supported");
                return block_fft_implementation_t::shared_memory_size * ffts_per_block;
            }

            inline static constexpr unsigned int get_storage_size() {
                static_assert(base_type::is_complete, "Can't calculate storage_size, FFT description is not complete");
                using database::detail::block_fft_record;
                using database::detail::search_by_ept;

                using block_fft_record_t = block_fft_record<base_type::this_fft_size_v,
                                                            this_fft_precision_t,
                                                            base_type::this_fft_type_v,
                                                            base_type::this_fft_direction_v,
                                                            CUFFTDX_DETAIL_EXECUTION_SM_VALUE>;
                static_assert(block_fft_record_t::defined, "This FFT configuration is not supported");
                using block_fft_implementation_t =
                    typename search_by_ept<elements_per_thread, typename block_fft_record_t::blobs>::type;
                static_assert(!std::is_void<block_fft_implementation_t>::value,
                              "This FFT configuration is not supported");
                return block_fft_implementation_t::storage_size;
            }

        public:
            static constexpr dim3         block_dim = check_and_get_trait<fft_operator::block_dim, base_type>::value;
            static constexpr unsigned int ffts_per_block =
                check_and_get_trait<fft_operator::ffts_per_block, base_type>::value;
            static constexpr unsigned int elements_per_thread = base_type::elements_per_thread;

            static constexpr unsigned int suggested_ffts_per_block =
                check_and_get_trait<fft_operator::ffts_per_block, base_type>::suggested;

            static constexpr unsigned int storage_size       = get_storage_size();
            static constexpr unsigned int shared_memory_size = get_shared_memory_size();

            static constexpr unsigned int max_threads_per_block         = block_dim.x * block_dim.y * block_dim.z;
            static constexpr unsigned int min_blocks_per_multiprocessor = 1;

            static constexpr unsigned int implicit_type_batching = std::is_same<this_fft_precision_t, __half>::value ? 2 : 1;
        };

        template<class... Operators>
        constexpr dim3 fft_block_execution<Operators...>::block_dim;
        template<class... Operators>
        constexpr unsigned int fft_block_execution<Operators...>::ffts_per_block;
        template<class... Operators>
        constexpr unsigned int fft_block_execution<Operators...>::elements_per_thread;
        template<class... Operators>
        constexpr unsigned int fft_block_execution<Operators...>::suggested_ffts_per_block;
        template<class... Operators>
        constexpr unsigned int fft_block_execution<Operators...>::storage_size;
        template<class... Operators>
        constexpr unsigned int fft_block_execution<Operators...>::shared_memory_size;
        template<class... Operators>
        constexpr unsigned int fft_block_execution<Operators...>::max_threads_per_block;
        template<class... Operators>
        constexpr unsigned int fft_block_execution<Operators...>::min_blocks_per_multiprocessor;
        template<class... Operators>
        constexpr unsigned int fft_block_execution<Operators...>::implicit_type_batching;

        // [NOTE] Idea for testing static assert.
        //
        // Switch (macro) which changes behaviour from going to static_asserts
        // to returning description_error type in operator+(). That would required more indirection
        // in creating fft_description and fft_execution types.

        template<class... Operators>
        struct make_description {
        private:
            static constexpr bool has_block_operator =
                has_operator<fft_operator::block, fft_execution<Operators...>>::value;
            static constexpr bool has_thread_operator =
                has_operator<fft_operator::thread, fft_execution<Operators...>>::value;
            static constexpr bool has_execution_operator = has_block_operator || has_thread_operator;

            using description_type = fft_description<Operators...>;
            using execution_type   = typename std::conditional<has_block_operator,
                                                             fft_block_execution<Operators...>,
                                                             fft_thread_execution<Operators...>>::type;

        public:
            using type = typename std::conditional<has_execution_operator, execution_type, description_type>::type;
        };

        template<class... Operators>
        using make_description_t = typename make_description<Operators...>::type;
    } // namespace detail

    template<class Operator1, class Operator2>
    __host__ __device__ __forceinline__
    auto operator+(const Operator1&, const Operator2&) //
        -> typename std::enable_if<detail::are_operator_expressions<Operator1, Operator2>::value,
                                   detail::make_description_t<Operator1, Operator2>>::type {
        return detail::make_description_t<Operator1, Operator2>();
    }

    template<class... Operators1, class Operator2>
    __host__ __device__ __forceinline__
    auto operator+(const detail::fft_description<Operators1...>&, const Operator2&) //
        -> typename std::enable_if<detail::is_operator_expression<Operator2>::value,
                                   detail::make_description_t<Operators1..., Operator2>>::type {
        return detail::make_description_t<Operators1..., Operator2>();
    }

    template<class Operator1, class... Operators2>
    __host__ __device__ __forceinline__
    auto operator+(const Operator1&, const detail::fft_description<Operators2...>&) //
        -> typename std::enable_if<detail::is_operator_expression<Operator1>::value,
                                   detail::make_description_t<Operator1, Operators2...>>::type {
        return detail::make_description_t<Operator1, Operators2...>();
    }

    template<class... Operators1, class... Operators2>
    __host__ __device__ __forceinline__
    auto operator+(const detail::fft_description<Operators1...>&, const detail::fft_description<Operators2...>&) //
        -> detail::make_description_t<Operators1..., Operators2...> {
        return detail::make_description_t<Operators1..., Operators2...>();
    }
} // namespace cufftdx

#endif // CUFFTDX_DETAIL_FFT_EXECUTION_HPP
